package com.messenger.isks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsksApplicationTests {

    @Test
    void contextLoads() {
    }

}
