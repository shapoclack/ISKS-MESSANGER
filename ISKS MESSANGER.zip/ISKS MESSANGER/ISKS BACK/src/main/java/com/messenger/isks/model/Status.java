package com.messenger.isks.model;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
